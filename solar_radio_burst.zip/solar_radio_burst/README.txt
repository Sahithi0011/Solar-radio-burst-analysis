# Solar Radio Burst Analysis for Early Detection of Space-Weather-Induced Communication Disturbances

## Project Description
This project analyses solar radio spectrogram data to identify candidate radio burst events using background subtraction and threshold-based signal processing.

## Source Code
- `analyze_burst.py` — Python source code for the analysis.

## Dataset
The analysis uses an e-CALLISTO FITS dataset:
`BLENSW_20140128_113000_59.fit.gz`

Place the dataset in the location expected by the Python script, or update the dataset path in the script before running it.

## Main Processing Steps
1. Load the FITS spectrogram data.
2. Extract frequency and time information.
3. Estimate and subtract the background signal.
4. Detect candidate transient events using a robust threshold.
5. Save detection results and visualisations.

## Software and Libraries
- Python
- NumPy
- Matplotlib
- Astropy
- Pandas (if required by the script)

## Important Note
Detected events are candidate radio transients. Their solar origin and any relationship to communication disturbances require independent validation.