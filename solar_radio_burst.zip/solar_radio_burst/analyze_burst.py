
from pathlib import Path

import numpy as np
import matplotlib.pyplot as plt
from astropy.io import fits

folder = Path(__file__).resolve().parent
fits_file = folder / "BLENSW_20140128_113000_59.fit.gz"

with fits.open(fits_file) as hdul:
    raw = np.asarray(hdul[0].data, dtype=float)
    freqs = np.asarray(hdul[1].data["frequency"][0], dtype=float).squeeze()
    times = np.asarray(hdul[1].data["time"][0], dtype=float).squeeze()

# Background subtraction per frequency channel
background = np.nanmedian(raw, axis=1, keepdims=True)
corrected = raw - background

# Analyze a window around the main transient
start_time = 265.0
end_time = 315.0
time_mask = (times >= start_time) & (times <= end_time)

if not np.any(time_mask):
    raise ValueError("No time samples found in the requested analysis window.")

window_data = corrected[:, time_mask]
window_times = times[time_mask]

# Find strongest pixel in the selected window
peak_index = np.unravel_index(np.nanargmax(window_data), window_data.shape)
peak_frequency = freqs[peak_index[0]]
peak_time = window_times[peak_index[1]]
peak_intensity = window_data[peak_index]

# Calculate average excess intensity across frequency channels
mean_intensity = np.nanmean(window_data, axis=0)
median_intensity = np.nanmedian(window_data, axis=0)

print("MAIN TRANSIENT WINDOW ANALYSIS")
print("------------------------------")
print(f"Analysis window: {start_time:.2f}–{end_time:.2f} seconds")
print(f"Peak time: {peak_time:.2f} seconds")
print(f"Peak frequency: {peak_frequency:.2f} MHz")
print(f"Peak background-subtracted digital intensity: {peak_intensity:.2f}")
print(f"Maximum mean intensity across channels: {np.nanmax(mean_intensity):.2f}")
print(f"Maximum median intensity across channels: {np.nanmax(median_intensity):.2f}")

# Save measurements at each time sample
csv_path = folder / "main_transient_time_series.csv"
np.savetxt(
    csv_path,
    np.column_stack((window_times, mean_intensity, median_intensity)),
    delimiter=",",
    header="time_s,mean_background_subtracted_intensity,median_background_subtracted_intensity",
    comments="",
)
print("Saved time-series data:", csv_path)

# Plot mean intensity over time
fig, ax = plt.subplots(figsize=(10, 4))
ax.plot(window_times, mean_intensity, label="Mean across frequency channels")
ax.plot(window_times, median_intensity, label="Median across frequency channels")
ax.axvline(peak_time, linestyle="--", label="Strongest pixel time")
ax.set_xlabel("Time [s]")
ax.set_ylabel("Background-subtracted digital intensity")
ax.set_title("Intensity Evolution of Main Radio Transient")
ax.grid(True, alpha=0.3)
ax.legend()
fig.tight_layout()
fig.savefig(folder / "main_transient_intensity.png", dpi=200)

plt.show()
